﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PROJECT_DBMS_FA20BSSE0062
{
    public partial class Form7 : Form
    {
        string address = @"Data source=DESKTOP-DSM2EG7\SHAHZAIBHAMZA;Initial catalog=FA20BSSE0062_project_DBMS;Integrated Security=True ";
        SqlConnection connection;
        SqlCommand command;
        String acc = Form2.accountNo;
        public Form7()
        {
            InitializeComponent();
            connection = new SqlConnection(address);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
            this.Hide();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            panel3.BackColor = Color.FromArgb(185, Color.Black);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (pinTB.Text == " " || conpinTB.Text == " ")
            {
                MessageBox.Show("Enter same Pin in both columns____!!!!");
            }
            else if (pinTB.Text!=conpinTB.Text) 
            {
                MessageBox.Show("NEW PIN AND CONFIRM PIN ARE NOT SAME_____!!!");
            }
            else
            {
                //  newbalance = oldbalance + Convert.ToInt32(depsoittb.Text);
                try
                {
                    connection.Open();
                    String query = "update sign_up set pin=" + pinTB.Text + " where acc_num='" + acc + "'";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("PIN CODE UPDATED_____!!!!");
                    connection.Close();
                    Form2 f2 = new Form2();
                    f2.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
