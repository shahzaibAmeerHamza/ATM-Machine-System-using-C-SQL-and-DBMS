﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PROJECT_DBMS_FA20BSSE0062
{
    public partial class Form4 : Form
    {
        string address = @"Data source=DESKTOP-DSM2EG7\SHAHZAIBHAMZA;Initial catalog=FA20BSSE0062_project_DBMS;Integrated Security=True ";
        SqlConnection connection;
        public Form4()
        {
            InitializeComponent();
            connection = new SqlConnection(address);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            panel1.BackColor = Color.FromArgb(185, Color.Black);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        public static String accountNo;
        private void Form4_Load(object sender, EventArgs e)
        {
           lb2.Text = Form2.accountNo;
           accountNo = Form2.accountNo;
            getName();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
          Form5 f5 = new Form5();
            this.Hide();
            f5.Show();
        }

        
         public void getName()
        {
            connection.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select fname from sign_up where acc_num='" + lb2.Text + "'", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lb3.Text = dt.Rows[0][0].ToString();
            connection.Close();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            this.Hide();
            f6.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form7 f7 = new Form7();
            f7.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 f8 = new Form8();
            f8.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form9 f9 = new Form9();
            f9.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form10 f10 = new Form10();
            f10.Show();
            this.Hide();
        }
        String acc = Form2.accountNo;
        private void button9_Click(object sender, EventArgs e)
        {
           
        }
    }
}
