﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PROJECT_DBMS_FA20BSSE0062
{
    public partial class Form9 : Form
    {
        string address = @"Data source=DESKTOP-DSM2EG7\SHAHZAIBHAMZA;Initial catalog=FA20BSSE0062_project_DBMS;Integrated Security=True ";
        SqlConnection connection;
        String acc = Form2.accountNo;

        public void populate() 
        {
            connection.Open();
            String query = "select*from tran_saction where AccNo='" + acc + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query,connection);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            statements.DataSource = ds.Tables[0];
            connection.Close();
        }
        public Form9()
        {
            InitializeComponent();
            connection = new SqlConnection(address);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
            this.Hide();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            populate();
        }
    }
}
