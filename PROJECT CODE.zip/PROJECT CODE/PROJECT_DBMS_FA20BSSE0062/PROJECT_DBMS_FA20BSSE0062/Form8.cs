﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PROJECT_DBMS_FA20BSSE0062
{
    public partial class Form8 : Form
    {
        string address = @"Data source=DESKTOP-DSM2EG7\SHAHZAIBHAMZA;Initial catalog=FA20BSSE0062_project_DBMS;Integrated Security=True ";
        SqlConnection connection;
        SqlCommand command;
        String acc = Form2.accountNo;
        public Form8()
        {
            InitializeComponent();
            connection = new SqlConnection(address);
        }
        int bal;
        public void getBalance()
        {
            connection.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select balance from sign_up where acc_num='" + acc + "'", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            balancelbl.Text = "BALANCE: "+dt.Rows[0][0].ToString();
            bal = Convert.ToInt32(dt.Rows[0][0].ToString());
            connection.Close();
            

        }

        public void addtransaction()
        {
            String typer = "Withdraw";

            connection.Open();
            command = new SqlCommand("insert into  tran_saction(AccNo,type,amount,Tdate) values ('" + acc + "','" + typer + "','" + wtb.Text + "','" + DateTime.Today.Date.ToString() + "')", connection);
            command.ExecuteNonQuery();
            connection.Close();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            panel3.BackColor = Color.FromArgb(185, Color.Black);
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            getBalance();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.ShowDialog();
            this.Hide();
        }
        int newbalance;
        private void button2_Click(object sender, EventArgs e)
        {
            if (wtb.Text == " ")
            {
                MessageBox.Show("PLEASE FILL THE AMOUNT TO WITHDRWAW OR BACK TO HOME__!!!");
            }
            else if (Convert.ToInt32(wtb.Text) <= 0)
            {
                MessageBox.Show("AMOUNT NOT VALID___!!!");
            }
            else if (Convert.ToInt32(wtb.Text) > bal)
            {
                MessageBox.Show("YOU DONT HAVE THAT AMOUNT TO WITHDRAW___!!!");
            }
            else 
            {
                try
                {
                    newbalance = bal - Convert.ToInt32(wtb.Text);
                    try
                    {
                        connection.Open();
                        String query = "update sign_up set balance=" + newbalance + " where acc_num='" + acc + "'";
                        SqlCommand cmd = new SqlCommand(query, connection);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Amount Withdrawn Successfully_____!!!!");
                        connection.Close();
                        addtransaction();
                        Form4 f4 = new Form4();
                        f4.Show();
                        this.Hide();
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }
        }
    }
}
