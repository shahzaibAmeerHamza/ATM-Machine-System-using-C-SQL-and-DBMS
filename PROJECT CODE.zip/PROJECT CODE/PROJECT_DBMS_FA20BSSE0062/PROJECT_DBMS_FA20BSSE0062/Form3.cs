﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PROJECT_DBMS_FA20BSSE0062
{
    public partial class Form3 : Form
    {
        string address = @"Data source=DESKTOP-DSM2EG7\SHAHZAIBHAMZA;Initial catalog =FA20BSSE0062_project_DBMS;Integrated Security=True ";
        SqlConnection connection;
        SqlCommand command;
        public Form3()
        {
            InitializeComponent();
            connection = new SqlConnection(address);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            panel1.BackColor = Color.FromArgb(165, Color.Black);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //if any feild empty
            if (Accno.Text == " " || Pin.Text == " " || Fname.Text == " " || Lname.Text == " " || Phone.Text == " " || Adress.Text == " " || Education.Text == " " || dateTimePicker1.Text == " " || Occ.Text == " ")
            {
                MessageBox.Show("PLEASE FILL ALL THE FEILDS------!!!");
            }

            //if password dont match confirm password
            if (Pin.Text != Confirm_PIN.Text)
            {
                MessageBox.Show("PASSWORD DONT MATCH------!!!");
            }

            //else run the program and enter data to sql
            else {

                connection.Open();
                command = new SqlCommand("insert into sign_up(acc_num, pin,fname,lname,phone,adress,education,DOB,occupation) values ('" + Accno.Text + "','" + Pin.Text + "','" + Fname.Text + "','" + Lname.Text + "','" + Phone.Text + "','" + Adress.Text + "','" + Education.Text + "','" + dateTimePicker1.Text + "','" + Occ.Text + "')", connection);
                command.ExecuteNonQuery();
                MessageBox.Show("ACCOUNT CREATED.... !!!!!");
                connection.Close();

                //enter to the login form to login to the created account
                Form2 f2 = new Form2();
                f2.ShowDialog();
                this.Hide();
            } }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


    }
}
