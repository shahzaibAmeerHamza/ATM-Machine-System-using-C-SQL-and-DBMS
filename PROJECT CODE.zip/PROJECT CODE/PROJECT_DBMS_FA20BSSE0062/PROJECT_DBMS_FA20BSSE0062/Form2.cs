﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PROJECT_DBMS_FA20BSSE0062
{
   
    public partial class Form2 : Form
    {
        public static String accountNo;
        string address = @"Data source=DESKTOP-DSM2EG7\SHAHZAIBHAMZA;Initial catalog=FA20BSSE0062_project_DBMS;Integrated Security=True ";
        SqlConnection connection;
        SqlCommand command;
        public Form2()
        {
            InitializeComponent();
            connection = new SqlConnection(address);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            this.Hide();
            f3.Show();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            panel3.BackColor = Color.FromArgb(165, Color.White);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select count(*) from sign_up where acc_num='"+ accBox.Text +"'AND pin = "+pinbox.Text+"", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
                accountNo = accBox.Text;
                Form4 f4 = new Form4();
                f4.Show();
                this.Hide();
                connection.Close();
            }else
            {
                MessageBox.Show("INVALID ACCOUNT NUMBER OR PASSWORD_____!!!!");
            }
            connection.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        public void getBalance() 
        {
        
        }
    }
}
