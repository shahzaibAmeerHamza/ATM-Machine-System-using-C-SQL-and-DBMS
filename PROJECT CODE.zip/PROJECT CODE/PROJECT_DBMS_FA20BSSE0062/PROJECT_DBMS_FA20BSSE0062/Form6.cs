﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PROJECT_DBMS_FA20BSSE0062
{
    public partial class Form6 : Form
    {
        string address = @"Data source=DESKTOP-DSM2EG7\SHAHZAIBHAMZA;Initial catalog=FA20BSSE0062_project_DBMS;Integrated Security=True ";
        SqlConnection connection;
        SqlCommand command;
        String acc = Form2.accountNo;
        public Form6()
        {
            InitializeComponent();
            connection = new SqlConnection(address);
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            panel3.BackColor = Color.FromArgb(185, Color.Black);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            this.Hide();
            f4.Show();
        }

        public void addtransaction() 
        {
            String typer = "DEPOSIT";
            
            connection.Open();
            command = new SqlCommand("insert into  tran_saction(AccNo,type,amount,Tdate) values ('" +acc+ "','" +typer+ "','" +depsoittb.Text+"','" + DateTime.Today.Date.ToString() + "')", connection);
            command.ExecuteNonQuery();
            connection.Close();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (depsoittb.Text == " " || Convert.ToInt32(depsoittb.Text) <= 0)
            {
                MessageBox.Show("Please Depsoit Amount____!!!!");
            }
            else 
            {
                newbalance = oldbalance + Convert.ToInt32(depsoittb.Text);
                try
                {
                    connection.Open();
                    String query = "update sign_up set balance=" + newbalance + " where acc_num='" + acc + "'";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Amount Deposited Successfully_____!!!!");
                    connection.Close();
                    addtransaction();
                    Form4 f4 = new Form4();
                    f4.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
       

        int oldbalance, newbalance;

        private void Form6_Load(object sender, EventArgs e)
        {
            getBalance();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        public void getBalance()
        {
            connection.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select balance from sign_up where acc_num='" + acc + "'", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            oldbalance=Convert.ToInt32(dt.Rows[0][0].ToString());
            connection.Close();

        }

        
    }
}
