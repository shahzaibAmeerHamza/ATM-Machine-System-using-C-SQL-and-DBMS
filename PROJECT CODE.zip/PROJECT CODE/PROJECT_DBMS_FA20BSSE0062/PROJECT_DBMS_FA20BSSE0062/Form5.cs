﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PROJECT_DBMS_FA20BSSE0062
{
    public partial class Form5 : Form
    {
        string address = @"Data source=DESKTOP-DSM2EG7\SHAHZAIBHAMZA;Initial catalog=FA20BSSE0062_project_DBMS;Integrated Security=True ";
        SqlConnection connection;
        public Form5()
        {
            InitializeComponent();
            connection = new SqlConnection(address);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            this.Hide();
            f4.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            panel2.BackColor = Color.FromArgb(185, Color.Black);
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            panel3.BackColor = Color.FromArgb(185, Color.Black);
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            lb1.Text = Form4.accountNo;
            getBalance();
        }

        public void getBalance()
        {
            connection.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select balance from sign_up where acc_num='" + lb1.Text + "'", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lb2.Text = dt.Rows[0][0].ToString();
            connection.Close();

        }
    }
}

