create database FA20BSSE0062_project_DBMS
use FA20BSSE0062_project_DBMS

create table sign_up
(
acc_num int primary key not null,
pin int not null,
fname varchar(50) not null,
lname varchar(50) not null,
phone BigInt not null,
adress varchar(50) not null,
education varchar(20) not null,
DOB varchar(40) not null,
occupation varchar (50) not null,
balance int default 0 
)


create table tran_saction
(
Tid int primary key not null identity(1,1),
AccNo varchar(50) not null,
type varchar(20) not null,
amount int not null,
Tdate varchar(50) not null,
)

drop table sign_up
drop table tran_saction


select*from sign_up

select*from tran_saction

